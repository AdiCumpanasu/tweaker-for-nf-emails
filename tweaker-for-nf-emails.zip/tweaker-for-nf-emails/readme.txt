=== Tweaker for Ninja Foms emails ===
Donate link: https://www.paypal.com/donate/?hosted_button_id=QTL9NDL2BJYLL
Contributors: adicumpanasu, freemius
Tags: ninja forms, emails tweaker, email layout, email highlighter, email alerts, email enhancer
Requires at least: 6.0
Tested up to: 6.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Unofficial addon for Ninja Forms.
This gives you a few features to conditionaly highlight fields in the submission email received from Ninja Forms.
This is done for now based on keywords found in the questions or in the replies or a combination.
It can also automatically give numbers to the fields.

More features are coming. Please use the donate button to support and motivate.

== Installation ==

1. Install and activate the plugin.
2. Be sure that you have the plugin Ninja Forms already instaled and activated because the current plugin works as an addon for Ninja Forms.
3. The configuration page will be under Wordrpess setings menu
4. Enjoy it ;)

== Screenshots ==

1. Example of settings page
2. Example of email highlighted and with numeric fields

== Changelog ==

= 1.0 =
* Initial version